import PostJob from "../PostJob/PostJob";

const PostJobPage = ()=>{
    return(
        <div className="min-h-[90vh] bg-gray-900">
            <PostJob/>    
        </div>
    )
}
export default PostJobPage;